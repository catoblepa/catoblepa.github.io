/* $Id: e2p_sort_by_ext.c 475 2007-07-09 11:42:44Z tpgww $

Copyright (C) 2003-2007 tooar <tooar@gmx.net>
Portions copyright (C) 1999 Michael Clark

This file is part of emelFM2.
emelFM2 is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

emelFM2 is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with emelFM2; see the file GPL. If not, contact the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

/**
@file plugins/e2p_sort_by_ext.c
@brief plugin to enable sorting of filelists by extension, instead of by name
This is effectively redundant, pressing <Control> before a sort-click achieves
the same effect
*/

#include "emelfm2.h"
#include <string.h>
#include "e2_plugins.h"
#include "e2_filelist.h"

extern gint stored_col_order[2][MAX_COLUMNS];
extern gint displayed_col_order[2][MAX_COLUMNS];

/**
@brief sort active filepane by item-extension

@param from the button, menu item etc which was activated
@param art action runtime data

@return TRUE
*/
static gboolean _e2p_sort_by_ext (gpointer from, E2_ActionRuntime *art)
{
	//replace the sort function for filename column of liststore
	//sortable uses base model, even with filter-model parent
    GtkTreeSortable *sortable = GTK_TREE_SORTABLE (curr_view->store);
	gint sortcolnow;
	GtkSortType sort_order = curr_view->sort_order;

	if (curr_view->extsort)
		//already extension-sorted, toggle direction
		curr_view->sort_order = (sort_order == GTK_SORT_ASCENDING) ?
			GTK_SORT_DESCENDING : GTK_SORT_ASCENDING;
	else
		curr_view->extsort = TRUE;

	gtk_tree_sortable_get_sort_column_id (sortable, &sortcolnow, &sort_order);
	gtk_widget_hide (curr_view->sort_arrows[sortcolnow]);
	gtk_arrow_set (GTK_ARROW (curr_view->sort_arrows[FILENAME]),
		(curr_view->sort_order == GTK_SORT_ASCENDING) ?
			 GTK_ARROW_RIGHT : GTK_ARROW_LEFT, GTK_SHADOW_IN);
	gtk_widget_show (curr_view->sort_arrows[FILENAME]);

	gtk_tree_sortable_set_sort_func (sortable, FILENAME,
		(GtkTreeIterCompareFunc) e2_fileview_ext_sort, &sort_order, NULL);
	//do the sort
	gtk_tree_sortable_set_sort_column_id (sortable, FILENAME, curr_view->sort_order);
	return TRUE;
}

//aname must be confined to this module
static gchar *aname;
/**
@brief plugin initialization function, called by main program

@param p ptr to plugin data struct

@return TRUE if the initialization succeeds, else FALSE
*/
gboolean init_plugin (Plugin *p)
{
#define ANAME "sort_by_ext"
  aname = _("sort_by_ext");

  p->signature = ANAME VERSION;
  p->menu_name = _("Extension _sort");
  p->description = _("Sort the active file pane by filename extension");
  p->icon = "plugin_extsort_"E2IP".png";  //use icon file pathname if appropriate

  if (p->action == NULL)
  {
	//no need to free this
	gchar *action_name = g_strconcat (_A(10),".",aname,NULL);
	p->action = e2_plugins_action_register
	  (action_name, E2_ACTION_TYPE_ITEM, _e2p_sort_by_ext, NULL, FALSE, 0, NULL);
	return TRUE;
  }
  return FALSE;
}
/**
@brief cleanup transient things for this plugin

@param p pointer to data struct for the plugin

@return TRUE if all cleanups were completed
*/
gboolean clean_plugin (Plugin *p)
{
  gchar *action_name = g_strconcat (_A(10),".",aname,NULL);
  gboolean ret = e2_plugins_action_unregister (action_name);
  g_free (action_name);
  return ret;
}
