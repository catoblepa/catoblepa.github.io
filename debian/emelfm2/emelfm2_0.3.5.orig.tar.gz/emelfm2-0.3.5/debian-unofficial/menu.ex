?package(emelfm2): needs=X11 section="Apps/Tools"\
  title="emelFM2" command="/usr/X11R6/bin/emelfm2"\
  longtitle="2-pane Gtk+2 file manager" \
  icon="/usr/share/pixmaps/emelfm2/emelfm2_48.png"
