/* $Id: e2_cl_option.h 545 2007-07-20 12:49:59Z tpgww $

Copyright (C) 2003-2007 tooar <tooar@gmx.net>

This file is part of emelFM2.
emelFM2 is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

emelFM2 is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with emelFM2; see the file GPL. If not, contact the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

#ifndef E2_CL_OPTION_H
#define E2_CL_OPTION_H

#include "emelfm2.h"

typedef struct _E2_CommandLineOptions
{
	gchar *pane1_path;	//entered string, converted before use to utf-8 if needed
	gchar *pane2_path;	//ditto
	gchar *config_dir;	//utf-8 string, no trailing /
	gchar *trash_dir;	//ditto
	gchar *encoding;
	gchar *fallback_encoding;
	gchar **overrides;
#ifdef DEBUG_MESSAGES
	gint debug_level;
#endif
	gboolean detached;
	gboolean verbose;
	gboolean suppress_gtk_log;
	gboolean ignore_problems;
	GList *option_overrides;
	GList *startup_commands;
} E2_CommandLineOptions;

E2_CommandLineOptions e2_cl_options; //FIXME cleanup when session ends ?

void e2_cl_option_process (gint argc, gchar *argv[]);

#endif //ndef E2_CL_OPTION_H
