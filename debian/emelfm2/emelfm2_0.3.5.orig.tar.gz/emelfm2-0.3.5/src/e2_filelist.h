/* $Id: e2_filelist.h 539 2007-07-18 11:52:43Z tpgww $

Copyright (C) 2004-2007 tooar <tooar@gmx.net>

This file is part of emelFM2.
emelFM2 is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

emelFM2 is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with emelFM2; see the file GPL. If not, contact the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

#ifndef E2_FILELIST_H
#define E2_FILELIST_H

#include "emelfm2.h"

/*enum { FILENAME = 0, SIZE, PERM, OWNER, GROUP,  see e2.h
	MODIFIED, ACCESSED, CHANGED }; //, MAX_COLUMNS }; */
//additional model columns, not displayed
enum { NAMEKEY = MAX_COLUMNS,
	FINFO, FORECOLOR, BACKCOLOR,
#ifdef E2_SELTXT_RECOLOR
	SELCOLOR,
#endif
	MODEL_COLUMNS };  //VISIBLE, MODEL_COLUMNS };

typedef enum
{
	PANE1, PANE2, PANEACTIVE, PANEINACTIVE
} E2_ListChoice;

typedef struct _E2_Column
{
	gchar *title;
	gint size;	//default width
	gint (*sort_func) ();
} E2_Column;

//gboolean order;  //sort order flag, TRUE for ascending, FALSE for descending
E2_Column e2_all_columns[MAX_COLUMNS];

void e2_filelist_disable_one_refresh (E2_ListChoice pane);
void e2_filelist_enable_one_refresh (E2_ListChoice pane);
gboolean e2_filelist_disable_refresh_action (gpointer from, E2_ActionRuntime *art);
gboolean e2_filelist_enable_refresh_action (gpointer from, E2_ActionRuntime *art);
void e2_filelist_disable_refresh (void);
//void e2_filelist_set_refresh (guint interval);
//void e2_filelist_set_refresh_custom (guint interval);
void e2_filelist_reset_refresh (void);
void e2_filelist_enable_refresh (void);
void e2_filelist_enable_refresh_custom (guint interval);
gboolean e2_filelist_request_refresh (gchar *dir, gboolean immediate);
//void e2_filelist_request_focus (GtkWidget *focus_wid);
gboolean e2_filelist_check_dirty (gpointer userdata);
GtkListStore *e2_filelist_fill_store (GList *entries, ViewInfo *view);
GtkListStore *e2_filelist_make_store (void);
gboolean e2_filelist_clear_old_stores (gpointer user_data);

#endif //ndef E2_FILELIST_H
