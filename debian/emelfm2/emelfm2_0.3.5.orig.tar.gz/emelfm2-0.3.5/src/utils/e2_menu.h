/* $Id: e2_menu.h 539 2007-07-18 11:52:43Z tpgww $

Copyright (C) 2004-2007 tooar <tooar@gmx.net>

This file is part of emelFM2.
emelFM2 is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

emelFM2 is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with emelFM2; see the file GPL. If not, contact the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

/**
@file src/utils/e2_menu.h
@brief Menu utilitiy functions header.

This is the header file for the menu utility functions.
*/

#ifndef E2_MENU_H
#define E2_MENU_H

typedef enum
{
	E2_CHILD_ALL,
	E2_CHILD_ACTIVE,
	E2_CHILD_OUTPUT,
} E2_ChildMenuType;

//callbacks
void e2_menu_destroy_cb (GtkWidget *menu, gpointer data);
void e2_menu_control_cb (GtkWidget *menu_item, gpointer data);

//public
void e2_menu_connect (GtkWidget *menu, gboolean  active);
void e2_menu_popup (GtkWidget *menu, gint button, guint32 time);
//FIXME: remove
/*#define add_menu_item(menu, label, func, data) \
	e2_menu_add (menu, label, NULL, NULL, func, data)
#define e2_menu_add_simple(menu, label, icon, func, data) \
	e2_menu_add (menu, label, icon, NULL, func, data) */
GtkWidget *e2_menu_add (GtkWidget *menu, gchar *label, gchar *icon,
	gchar *tip, void *func, gpointer data);

GtkWidget *e2_menu_add_action (GtkWidget *menu, gchar *label, gchar *icon,
	gchar *tip, gchar *action, gchar *arg, gpointer free);
GtkWidget *e2_menu_add_check (GtkWidget *menu, gchar *label,
	gboolean state, void *func, gpointer data);
GtkWidget *e2_menu_add_radio (GtkWidget *menu, GSList **group,
	gchar *label, gboolean state, void *func, gpointer data);
GtkWidget *e2_menu_add_separator (GtkWidget *menu);
GtkWidget *e2_menu_add_tear_off (GtkWidget *menu);
GtkWidget *e2_menu_add_submenu (GtkWidget *menu, gchar *label_text, gchar *icon);
GtkWidget *e2_menu_add_toggle (GtkWidget *menu, gchar *label, gchar *icon,
	gchar *tip, gchar *toggle, gchar *cmd);
GtkWidget *e2_menu_create_options_menu (GtkWidget *controller,
	GtkWidget *menu, E2_OptionSet *set, ...);
void e2_menu_create_bookmarks_menu (E2_Action *action,
	E2_OptionSet *set, GtkWidget *menu, GtkTreeIter *iter);
void e2_menu_create_plugins_menu (GtkWidget *menu, gboolean is_selection);
GtkWidget *e2_menu_create_child_menu (E2_ChildMenuType type, gpointer func);
GtkWidget *e2_menu_create_filter_menu (ViewInfo *view);
GtkWidget *e2_menu_create_custom_menu (gchar *name);
#ifdef E2_VFS
GtkWidget *e2_menu_create_vfs_menu (ViewInfo *view);
#endif
void e2_menu_custom_option_register (void);
#ifdef E2_FS_MOUNTABLE
gboolean e2_menu_create_mounts_menu (gpointer from, E2_ActionRuntime *art);
#endif

#endif //ndef E2_MENU_H
