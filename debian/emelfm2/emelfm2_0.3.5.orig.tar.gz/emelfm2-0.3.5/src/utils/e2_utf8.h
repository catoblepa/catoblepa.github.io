/* $Id: e2_utf8.h 469 2007-07-06 22:58:30Z tpgww $

Copyright (C) 2004-2007 tooar <tooar@gmx.net>

This file is part of emelFM2.
emelFM2 is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

emelFM2 is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with emelFM2; see the file GPL. If not, contact the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

/**
@file src/utils/e2_utf8.h
@brief utf8 string utilities header

This is the header file for the utf8 string utility functions.
*/

#ifndef E2_UTF8_H
#define E2_UTF8_H

//support for file paths/names ONLY in utf-8
//GLib and GTK+ by default assume that filenames are
//encoded in UTF-8 rather than some other encoding that
//is specific to a locale. ASCII is compatible with UTF-8
// the ..FILENAME_FROM.. macros make a utf8 name from a locale-encoded one
// the ..FILENAME_TO.. macros make a locale-encoded name from a utf8 one
//#define E2_FILES_UTF8ONLY - see Makefile
#ifdef E2_FILES_UTF8ONLY
#define F_DISPLAYNAME_FROM_LOCALE(d) d
//the D_ versions are for when a duplicate is needed
//regardless of whether E2_FILES_UTF8ONLY is defined or not
#define D_FILENAME_FROM_LOCALE(d) g_strdup(d)
#define D_FILENAME_TO_LOCALE(d) g_strdup(d)
//the F_ versions are for when there is an associated free of
//the created duplicate, when E2_FILES_UTF8ONLY is not defined
#define F_FILENAME_FROM_LOCALE(d) d
#define F_FILENAME_TO_LOCALE(d) d
#define F_FREE(d)
#else
/* this version of defines applies when build-time conversion code is used
#define D_FILENAME_FROM_LOCALE(d) e2_utf8_filename_from_locale(d)
#define D_FILENAME_TO_LOCALE(d) e2_utf8_filename_to_locale(d)
//#define F_FILENAME_FROM_LOCALE(d) _free_me_=e2_utf8_filename_from_locale(d)
//#define F_FILENAME_TO_LOCALE(d) _free_me_=e2_utf8_filename_to_locale(d)
//#define F_FREE g_free(_free_me_)
#define F_FILENAME_FROM_LOCALE(d) e2_utf8_filename_from_locale(d)
#define F_FILENAME_TO_LOCALE(d) e2_utf8_filename_to_locale(d)
#define F_FREE(d) g_free(d)
gchar *e2_utf8_filename_from_locale_backup (const gchar *d);
gchar *e2_utf8_filename_to_locale_backup (const gchar *d);
*/
// this version of defines applies when run-time conversion code is used
#define F_DISPLAYNAME_FROM_LOCALE(d) (*e2_display_from_locale)(d)
#define D_FILENAME_FROM_LOCALE(d) (*e2_fname_dupfrom_locale)(d)
#define D_FILENAME_TO_LOCALE(d) (*e2_fname_dupto_locale)(d)
#define F_FILENAME_FROM_LOCALE(d) (*e2_fname_from_locale)(d)
#define F_FILENAME_TO_LOCALE(d) (*e2_fname_to_locale)(d)
#define F_FREE(d) (*e2_fname_free)(d)
//pointers to functions used to convert (or not) coding of file path/name strings
gchar *(*e2_display_from_locale) (const gchar *);
gchar *(*e2_fname_to_locale) (const gchar *);
gchar *(*e2_fname_from_locale) (const gchar *);
gchar *(*e2_fname_dupto_locale) (const gchar *);
gchar *(*e2_fname_dupfrom_locale) (const gchar *);
void (*e2_fname_free) (gpointer);
//pointers set to these functions when coding conversion is not needed
gchar *e2_utf8_not_converted (const gchar *);
void e2_utf8_not_freed (gpointer);
//
#endif

#define NCHR(p) p=g_utf8_next_char(p)
#define PCHR(p) p=g_utf8_prev_char(p)

//inline
gchar *e2_utf8_filename_from_locale (const gchar *d);
//inline
gchar *e2_utf8_filename_to_locale (const gchar *d);
//inline
gchar *e2_utf8_to_locale (const gchar *d);
gchar *e2_utf8_to_locale_fallback (const gchar *d);
gchar *e2_utf8_from_locale (const gchar *d);
gchar *e2_utf8_from_locale_fallback (const gchar *d);
//macro for inlining speedier conversions
#define e2_utf8_from_locale_fast(d) \
 (g_utf8_validate (d, -1, NULL) ) ? g_strdup (d) : \
 ((__utf__ = g_locale_to_utf8 (d, -1, NULL, NULL, NULL)) != NULL) ? __utf__ : \
 e2_utf8_from_locale_fallback (d);

const gchar *e2_utf8_strcasestr (const gchar *haystack, const gchar *needle);
const gchar *e2_utf8_strrcasestr (const gchar *haystack, const gchar *needle);
gboolean e2_utf8_caseless_match (const gchar *s1, const gchar *s2, gssize n1,
	gssize n2);
gchar *e2_utf8_ndup (const gchar *str, glong num);
gchar *e2_utf8_escape (const gchar *str, gunichar c);
gchar *e2_utf8_unescape (const gchar *str, gunichar c);

gboolean e2_utf8_detect_charset (const gchar *text, const gchar **charset);

#endif // ndef E2_UTF8_H
