/* $Id: e2_filetype.h 469 2007-07-06 22:58:30Z tpgww $

Copyright (C) 2003-2007 tooar <tooar@gmx.net>

This file is part of emelFM2.
emelFM2 is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

emelFM2 is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with emelFM2; see the file GPL. If not, contact the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

#ifndef E2_FILETYPE_H
#define E2_FILETYPE_H

#include "emelfm2.h"

void e2_filetype_config_show (gchar *extension);
void e2_filetype_apply_allnew (void);
const gchar **e2_filetype_get_actions (gchar *ext);
//gchar **e2_filetype_get_extensions (gchar *category);
gchar *e2_filetype_get_default_action (gchar *ext);
// UNUSED gchar **e2_filetype_get (gchar *ext);
// OLD void add_filetype(gchar *ext, gchar *prog, gchar *desc);
void e2_filetype_add_all (void);
void e2_filetype_exec_action (gchar *action);
void	e2_filetype_actions_register (void);
void e2_filetype_options_register (void);

#endif //ndef E2_FILETYPE_H
