/* $Id: e2_password_dialog.h 482 2007-07-10 06:48:54Z tpgww $

Copyright (C) 2007 tooar <tooar@gmx.net>

This file is part of emelFM2.
emelFM2 is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

emelFM2 is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with emelFM2; see the file GPL. If not, contact the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

/**
@file src/dialogs/e2_password_dialog.h
@brief header file for password dialog
*/

#include "emelfm2.h"
#include "e2_dialog.h"

typedef struct _E2_PWDialogRuntime
{
	GtkWidget *dialog;		//the displayed dialog
	GtkWidget *pwentry1;
	GtkWidget *pwentry2;
	gboolean confirm;		//TRUE when requiring matching contents in pwentry1 and pwentr2
	gboolean hint;			//TRUE when the last char in either used entry is displayed as plaintext
	gboolean hide;			//TRUE when no entered char is to be echoed
	gboolean plain;			//TRUE when the entered text is displayed as is
	gboolean destroy;		//TRUE to destroy dialog and data after user's choice
	DialogButtons result;	//enumerator of what the user chose
	gchar **passwd;			//place to store entered (and validated) password
} E2_PWDialogRuntime;

E2_PWDialogRuntime *e2_password_dialog_setup (gchar *title, gchar *stock,
	gchar *prompt, gboolean confirm, OW_ButtonFlags extras, gchar **pw,
	gboolean destroy);
DialogButtons e2_password_dialog_run (gboolean threaded);
