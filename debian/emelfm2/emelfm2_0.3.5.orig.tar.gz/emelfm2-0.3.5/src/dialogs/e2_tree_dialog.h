/* $Id: e2_tree_dialog.h 469 2007-07-06 22:58:30Z tpgww $

Copyright (C) 2007 tooar <tooar@gmx.net>

This file is part of emelFM2.
emelFM2 is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

emelFM2 is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with emelFM2; see the file GPL. If not, contact the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

#ifndef _E2_TREE_DIALOG_H
#define _E2_TREE_DIALOG_H

#include "emelfm2.h"

#ifdef E2_TREEDIALOG
gboolean e2_tree_dialog_show_action (gpointer from, E2_ActionRuntime *art);
#endif

#endif //ndef _E2_TREE_DIALOG_H
