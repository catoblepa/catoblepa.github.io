/* $Id: e2_select_image_dialog.h 469 2007-07-06 22:58:30Z tpgww $

Copyright (C) 2003-2007 tooar <tooar@gmx.net>

This file is part of emelFM2.
emelFM2 is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

emelFM2 is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with emelFM2; see the file GPL. If not, contact the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

#ifndef E2_SELECT_IMAGE_DIALOG_H
#define E2_SELECT_IMAGE_DIALOG_H

#include "emelfm2.h"

typedef struct _E2_SID_Runtime
{
	gchar *name;
	gchar *icon; //gtk-stock-icon name, or path to icon file, taken from tree-option store
	GtkWidget *dialog;
	GtkWidget *parent;
	GtkNotebook *notebook;
	gint page;
	GtkWidget *file_chooser;
	GtkTreeModel *model;
	GtkTreeView *treeview;
} E2_SID_Runtime;

GtkWidget *e2_sid_create (GtkWidget *parent, const gchar *name,
	gchar *icon, gpointer response_func, E2_OptionSet *set);

#endif /* ifndef E2_SELECT_IMAGE_DIALOG_H */
