/* $Id: e2_permissions_dialog.h 469 2007-07-06 22:58:30Z tpgww $

Copyright (C) 2004-2007 tooar <tooar@gmx.net>

This file is part of emelFM2.
emelFM2 is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

emelFM2 is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with emelFM2; see the file GPL. If not, contact the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

#ifndef E2_PERMISSIONS_DIALOG_H
#define E2_PERMISSIONS_DIALOG_H

#include "emelfm2.h"
#include "e2_dialog.h"

typedef enum
{
	E2_RECURSE_NONE = 0,
	E2_RECURSE_DIRS = 1,
	E2_RECURSE_OTHER = 1 << 2,
	E2_RECURSE_ALL = 1 << 3
} E2_RecurseType;

DialogButtons e2_permissions_dialog_run (gchar *localpath, gchar **mode_ret,
	E2_RecurseType *recurse_ret, gboolean *permission_ret, gboolean multi);

#endif //ndef E2_PERMISSIONS_DIALOG_H
