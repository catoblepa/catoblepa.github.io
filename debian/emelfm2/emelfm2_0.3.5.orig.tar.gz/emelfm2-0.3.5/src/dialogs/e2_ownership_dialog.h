/* $Id: e2_ownership_dialog.h 469 2007-07-06 22:58:30Z tpgww $

Copyright (C) 2004-2007 tooar <tooar@gmx.net>

This file is part of emelFM2.
emelFM2 is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3, or (at your option)
any later version.

emelFM2 is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with emelFM2; see the file GPL. If not, contact the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

#ifndef E2_OWNERSHIP_DIALOG_H
#define E2_OWNERSHIP_DIALOG_H

#include "emelfm2.h"

// the maximum number of membership groups that a user may see
#define REPORTABLE_GROUPS 25
// the lowest alternate UID available to non-root users
#define UID_LOWLIMIT 500

void e2_ownership_dialog_warn (GtkWidget *box);
DialogButtons e2_ownership_dialog_run (gchar *localpath,
	uid_t *owner_ret, gid_t *group_ret,
	gboolean *recurse_ret, gboolean *permission_ret, gboolean multisrc);

#endif //ndef E2_OWNERSHIP_DIALOG_H
