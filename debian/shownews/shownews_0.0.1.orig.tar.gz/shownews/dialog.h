void ui_main_help (void);
void ui_feed_help (void);
void ui_item_help (void);
void UIAbout (void);
void UIChangeBrowser (void);
void ui_rename_feed (struct feed *cur_ptr);
void ui_add_feed ();
void FeedInfo (struct feed * current_feed);
struct feed* ui_delete_feed (struct feed* feed, char * feedname);
void CategorizeFeed (struct feed * current_feed);
char * DialogGetCategoryFilter (void);
int ui_add_category();
typedef enum {
	NORMAL,
	INVERSE
} howclearline;

void UIStatus (char * text, int delay, int warning);
void UISupportDrawBox (int x1, int y1, int x2, int y2);

