#include <mrss.h>

mrss_t* UpdateFeed (char* url);
int UpdateAllFeeds (void);
struct feed* load_feed (char* url, char* read_cache);
struct feed* load_category (char* category_name);
void write_cache (void);
void printlog (struct feed * feed, const char * text);
void new_feed(char* url);
int new_category(char* category_name);
mrss_t* load_cache(char* url);
bool* set_read(mrss_item_t* items);
bool* set_unread(mrss_item_t* items);
void swap_pointers (struct feed * one, struct feed * two);
void reload_feed(struct feed* current_feed);
void clean_cache(char* feed_file);
void launch_browser (char * url);
void freefeedstruct(struct feed* feed);
void export_opml(struct feed* first_feed);
