#include <ncurses.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <signal.h>
#include <mrss.h>

#include "main.h"
#include "conversions.h"
#include "dialog.h"
#include "io-internal.h"

extern char *browser;

void freefeedstruct(struct feed* feed){
	mrss_free(feed->element);
	free(feed->read);
	free(feed->category_name);
	free(feed->feed_name);
	free(feed);
}

struct feed* newfeedstruct (void) {
	
	struct feed *new;
	
	new = malloc(sizeof(struct feed));
	
	new->next = NULL;
	new->prev = NULL;
	new->element = NULL;
	new->write_cache = false;
	new->read = NULL;
	new->category = false;
	new->category_name = NULL;
	new->feed_name = NULL;
	return new;
}

void export_opml(struct feed* first_feed){
	FILE* opml_file = NULL;
	struct feed* feed = NULL;

	opml_file = fopen ("/home/sheep/feed.opml","w+");
	if (opml_file == NULL)
		 main_quit("Unable to open feed.opml file","NULL");

	fprintf(opml_file,"<?xml version=\"1.0\"?>\n");
	fprintf(opml_file,"<opml version=\"1.0\">\n");
	fprintf(opml_file,"<head>\n");
	fprintf(opml_file,"<title>Shownews - Exported Feeds</title>\n");
	fprintf(opml_file,"</head>\n");
	fprintf(opml_file,"<body>\n");

	for(feed = first_feed; feed->next!=NULL ; feed= feed->next)
		fprintf(opml_file,"\t\t<outline type=\"rss\" xmlUrl=\"%s\" htmlUrl=\"%s\" title=\"%s\" />\n",feed->element->file, feed->element->link,feed->element->title);

	fprintf(opml_file,"</body>\n");
	fprintf(opml_file,"</opml>\n");
	
	fclose(opml_file);
	UIStatus("Export file feed.opml: Ok!",1,0);
}

void swap_pointers (struct feed * one, struct feed * two) {
	struct feed *tmp;
	
	tmp = newfeedstruct();

	tmp->feed_name = one->feed_name;
	tmp->category_name = one->category_name;
	tmp->category = one->category;
	tmp->read = one->read;
	tmp->write_cache = one->write_cache;
	tmp->element = one->element;

	one->feed_name = two->feed_name;
	one->category_name = two->category_name;
	one->category = two->category;
	one->read = two->read;
	one->write_cache = two->write_cache;
	one->element = two->element;

	two->feed_name = tmp->feed_name;
	two->category_name = tmp->category_name;
	two->category = tmp->category;
	two->read = tmp->read;
	two->write_cache = tmp->write_cache;
	two->element = tmp->element;

	free (tmp);
}

bool* set_read(mrss_item_t* items){
	mrss_item_t* item = NULL;
	bool* read = NULL;
	int count = 0, i=0;

	for(item = items; item!=NULL; item=item->next)
		count++;

	read = malloc(count*sizeof(bool));

	for(i=0; i<count ; i++)
		read[i]=true;

	return read;
}
/*
 * Set all news as unread
 * @parameter
 * 	- items
 * @return
 * 	- bool[] all false
 */
bool* set_unread(mrss_item_t* items){

	mrss_item_t* item = NULL;
	bool* read = NULL;
	int count = 0, i=0;

	for(item = items; item!=NULL; item=item->next)
		count++;

	read = malloc(count*sizeof(bool));

	for(i=0; i<count ; i++)
		read[i]=false;

	return read;
}

mrss_t* load_cache(char* url){	
	char* file;
 	char* hashme;		// Hashed filename. 
	FILE* cache;
	mrss_t *new_ptr = NULL;
	mrss_error_t err;

	hashme = Hashify(url);
	int len = strlen(getenv("HOME"))+strlen("/.shownews/cache/")+strlen(hashme)+1;
	file = malloc(len);
	snprintf (file, len, "%s/.shownews/cache/%s", getenv("HOME"), hashme);
	
	free (hashme);

	cache = fopen (file, "r");
	
	if (cache != NULL){
		//Cache
		fclose(cache);

		mrss_new(&new_ptr);

		err= mrss_set(new_ptr, MRSS_FLAG_VERSION, MRSS_VERSION_0_92, MRSS_FLAG_TITLE, 
				url, MRSS_FLAG_TTL, 12, MRSS_FLAG_END);

		if(err!=MRSS_OK) 
			main_quit(mrss_strerror(err),strerror(err));

		err = mrss_parse_file(file,&new_ptr); 
		
		if(err!=MRSS_OK) {
			UIStatus("Cache parse error",1,1);
			new_ptr=NULL;
		} else {
			new_ptr->file = url;
			free(file);
		}
	} 

	return new_ptr;
}

mrss_t* load_net(char* url) {
	
	mrss_t *new_ptr = NULL;
	mrss_error_t err;
 	char tmp[1024];

	if (url == NULL)
		return NULL;

	new_ptr = NULL;
	mrss_new(&new_ptr);

	err= mrss_set(new_ptr, MRSS_FLAG_VERSION, MRSS_VERSION_0_92, MRSS_FLAG_TITLE, 
			url, MRSS_FLAG_TTL, 12, MRSS_FLAG_END);

	if(err!=MRSS_OK) 
		main_quit(mrss_strerror(err),strerror(err));
	
	UIStatus(url,0,0);
	mrss_options_t* options = mrss_options_new (time_out,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL);
	err = mrss_parse_url_with_options (url, &new_ptr, options);
	mrss_options_free(options);
	if(err!=MRSS_OK){ 
		snprintf (tmp, sizeof(tmp), "MRSS return error: %s ", mrss_strerror (err));
		UIStatus (tmp, 1, 1);
		new_ptr=NULL;
	}

	return new_ptr;
}
/*
 * convert string 00101 to bool
 * @return: bool[]
 * @parameter: read_cache, may be NULL
 */
bool* cache_to_bool(char* read_cache) {

	bool* read = NULL;
	int i = 0;

	if(read_cache == NULL)
		return NULL;
	
	read = malloc(strlen(read_cache)*sizeof(bool));
	for(i=0; i<strlen(read_cache); i++){
	
		if(read_cache[i]=='1')
			read[i] = true;
		else
			read[i] = false;

	}

	return read;
}
/*
 * Covert the url_element news'status to bool[]
 *
 */
bool* url_to_bool(char* read_cache_str, mrss_item_t* item_url, mrss_item_t* item_cache){

	bool* read = NULL;
	bool* read_cache = NULL;

	mrss_item_t* item_u = NULL;
	mrss_item_t* item_c = NULL;
	int j,i=0;

	//Convert char* to bool*
	read_cache = cache_to_bool(read_cache_str);

	// Mark all as unread
	read = set_unread(item_url);

	// Set old news the old status.
	for(item_u = item_url; item_u!=NULL; item_u = item_u->next){
		j=0;
		for(item_c = item_cache; item_c != NULL; item_c = item_c->next){

			if (strcmp(item_u->title, item_c->title) == 0){
				// Setto il valore che ha nella cache
				read[i]=read_cache[j];
				break;
			}
			j++;
		}
		i++;	
	}

	free(read_cache);

	return read;
}

struct feed* load_category(char* category_name){
        struct feed* category = NULL;

	category = newfeedstruct();
	category->category=true;
	category->category_name = strdup(category_name);

	return category;
}

void reload_feed(struct feed* current_feed){

	mrss_t *element_url = NULL;
	mrss_t *element_cache = NULL;
	mrss_item_t* item = NULL;

	if(current_feed->category)
		return;

	UIStatus(current_feed->element->file,0,0);
	element_url = load_net(current_feed->element->file);
	// Network error
	if(element_url == NULL){ 
		UIStatus("net error",1,0);
		return;
	}

	//element_cache = current_feed->element;
	element_cache = load_cache(current_feed->element->file);

	if(element_cache == NULL) {
		
		for(item = element_url->item; item!=NULL; item=item->next){
			item->title = ascii2utf8(UIDejunk(item->title));
			item->description = ascii2utf8(UIDejunk(item->description));
		}

		free(current_feed->read);
		current_feed->read = set_unread(element_url->item);
		current_feed->element = element_url;

	} else {
		// Check the title
		if (strcmp(element_url->item->title, element_cache->item->title) == 0){
			mrss_free(element_url);
			return;
		} else {
			for(item = element_url->item; item!=NULL; item=item->next){
				item->title = ascii2utf8(UIDejunk(item->title));
				item->description = ascii2utf8(UIDejunk(item->description));
			}	
			free(current_feed->read);
			current_feed->read = url_to_bool(bool_to_string(current_feed),element_url->item,element_cache->item);
			free(element_cache); // and also current_feed->element!
			current_feed->element = element_url;
		}
	}
	
	current_feed->write_cache = true;
}

/*
 * Load a feed
 * @return a new feed struct with
 * 	- read vector, may be null.
 * 	- element, may be null.
 * @parameter: 
 * 	- url
 * 	- read_cache: read status from cache (000111), may be NULL
 */
struct feed* load_feed (char* url, char* read_cache) {

	struct feed* new_feed = NULL;
	
	mrss_t *element_url = NULL;
	mrss_t *element_cache = NULL;
	mrss_item_t* item = NULL;
	mrss_error_t err;

	if(autoload) 
		element_url = load_net(url);
	

	// Activate the net, autoload == false only for first time
//	autoload=true;
	
	element_cache = load_cache(url);
	
	new_feed = newfeedstruct();
	
	// Network error
	if(element_url == NULL) {
		new_feed->read = cache_to_bool(read_cache);

		if(element_cache == NULL) {
			mrss_new(&element_cache);
			err= mrss_set(element_cache, MRSS_FLAG_VERSION, MRSS_VERSION_0_92, MRSS_FLAG_TITLE,
					url, MRSS_FLAG_TTL, 12, MRSS_FLAG_END);
			if(err!=MRSS_OK) 
				main_quit(mrss_strerror(err),strerror(err));
		}

		new_feed->element =  element_cache; 
	} else {

		if(element_cache == NULL) {
			for(item = element_url->item; item!=NULL; item=item->next){
				item->title = ascii2utf8(UIDejunk(item->title));
				item->description = ascii2utf8(UIDejunk(item->description));
			}

			new_feed->read = set_unread(element_url->item);

			new_feed->write_cache = true;
			new_feed->element = element_url;

		} else {
				
			// Check the title
			if (strcmp(element_url->item->title, element_cache->item->title) == 0) {
				new_feed->read = cache_to_bool(read_cache);
				new_feed->element = element_cache; 

			} else {

				for(item = element_url->item; item!=NULL; item=item->next){
					item->title = ascii2utf8(UIDejunk(item->title));
					item->description = ascii2utf8(UIDejunk(item->description));
				}	

				new_feed->read = url_to_bool(read_cache, element_url->item, element_cache->item);

				new_feed->write_cache = true;
				new_feed->element = element_url;
			}
		}
	}

	return new_feed;
}


void new_feed(char* url){
	
	struct feed* new_feed = NULL;
	
	new_feed = load_feed(url,NULL);
	
	// Add the feed to the list
        new_feed->next = first_ptr;

	if (first_ptr != NULL)
		first_ptr->prev = new_feed;

	new_feed->prev = NULL;
	first_ptr = new_feed;
}

int new_category(char* category_name){
	
	struct feed* category = NULL;
	char* title = NULL;

	category = newfeedstruct();
	category->category=true;

	title = malloc(strlen(category_name)+7);

	snprintf(title,strlen(category_name)+7,"== %s ==",category_name);
	category->category_name = strdup(title);
	
	// Add the feed to the list
        category->next = first_ptr;
	if (first_ptr != NULL)
		first_ptr->prev = category;
	category->prev = NULL;
	first_ptr = category;

	return 0;
}

/* Write in memory structures to disk cache.
 * Usually called before program exit.*/
void write_cache (void) {
	char* file;				// File locations. 
	char* hashme;				// Cache file name. 
	FILE* url_file;
	struct feed* cur_ptr;
	mrss_error_t err;
	mrss_item_t* item;
	int len,i;
	
	UIStatus ("Saving settings...", 0, 0);
	len = strlen(getenv("HOME"))+strlen("/.shownews/urls")+1;
	file = malloc(len);
	snprintf (file, len, "%s/.shownews/urls", getenv("HOME"));
	
	url_file = fopen (file, "w+");
	if (url_file == NULL) 
		main_quit ("Save settings (urls)", strerror(errno));
	
	for (cur_ptr = first_ptr; cur_ptr != NULL; cur_ptr = cur_ptr->next) {

		if(cur_ptr->category){
			fputs (cur_ptr->category_name, url_file);
		} else {
			if(cur_ptr->element->file==NULL)
				cur_ptr->element->file = strdup(cur_ptr->element->title);
			fputs (cur_ptr->element->file, url_file);
	
			fputc ('|',url_file);

			i=0;
			for(item= cur_ptr->element->item; item!=NULL; item=item->next){
				if(cur_ptr->read[i++])
					fputc('1',url_file);
				else
					fputc('0',url_file);
			}
	
			if(cur_ptr->feed_name!=NULL){
				fputc ('|', url_file);
				fprintf(url_file,"%s",cur_ptr->feed_name);
			}
		}
		fputc ('\n', url_file); 
	}
	fclose (url_file);
	
	// we NEED two separated cycle because write url file is very dangerous!
	// if an error occour, we lost the feed list!
	for (cur_ptr = first_ptr; cur_ptr != NULL; cur_ptr = cur_ptr->next) {
		
		// Write feed to cache!
		if(cur_ptr->category)
			hashme = Hashify(cur_ptr->category_name);
		else
			hashme = Hashify(cur_ptr->element->file);
	
		len = strlen(getenv("HOME"))+ strlen("/.shownews/cache/") +strlen(hashme)+1;
		file = malloc(len);
		snprintf (file, len,"%s/.shownews/cache/%s", getenv("HOME"), hashme);
		free (hashme);

		if(cur_ptr->write_cache){
			err = mrss_write_file(cur_ptr->element,file);
			if(err!=MRSS_OK)
				main_quit(mrss_strerror(err),strerror(err));
		}
	}
	
	free(file);
	return;
}

void launch_browser (char * url) {
	int len;
	char *tmp;
	char *escapetext = NULL;
	char *syscall = NULL;
	
	// Discard url if it contains a single quote! 
	if ((strstr(url, "'")) == NULL) {
		len = strlen(url) + 3;
		escapetext = malloc (len);
		snprintf (escapetext, len, "\'%s\'", url);
		len = strlen(browser) + len + 1;
		syscall = malloc (len);
		snprintf (syscall, len,"%s %s", browser, escapetext);
		free (escapetext);
	} else {
		UIStatus ("Invalid URL passed. Possible shell exploit attempted!", 3, 1);
		free (syscall);
		
		return;
	}
	
	UIStatus ("Launching browser..." , 0, 0);
	
	len = len + 13;
	tmp = malloc (len);
	snprintf (tmp, len, "%s 2>/dev/null", syscall);

	// Switch on the cursor.
	curs_set(1);

	endwin();
	
	system(tmp);

	init_curses();

	// Hide cursor again. 
	curs_set(0);

	free (tmp);

	free (syscall);
}

void clean_cache(char* feed_file){
	char* file;
	char* hashme;
	int len;

	if(feed_file == NULL)
		return;

	hashme = Hashify(feed_file);
	len = (strlen(getenv("HOME")) + strlen(hashme) + 18);
	file = malloc (len);
	snprintf(file,len,"%s/.shownews/cache/%s", getenv("HOME"),hashme);
	unlink (file);
	
	free (file);
	free (hashme);
}
