#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <libxml/HTMLparser.h>
#include <langinfo.h>
#include <mrss.h>

#include "main.h"
#include "conversions.h"
#include "interface.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

struct entity *first_entity;

char* putUTF8(int c){
        char* res=malloc(7*sizeof(long));
	res[0]='\0';
		
	if (c <= 0x7F) {                                // Leave ASCII encoded 
		sprintf(res,"&#%c;", c);
	} else if (c <= 0x07FF) {                       // 110xxxxx 10xxxxxx 
		sprintf(res,"%c%c",(0xC0 | (c >> 6)),(0x80 | (c & 0x3F)));
	} else if (c <= 0xFFFF) {                       // 1110xxxx + 2 
		sprintf(res,"%c%c%c",(0xE0 | (c >> 12)),(0x80 | ((c >> 6) & 0x3F)),(0x80 | (c & 0x3F)));
	} else if (c <= 0x1FFFFF) {                     // 11110xxx + 3 
		sprintf(res,"%c%c%c%c",(0xF0 | (c >> 18)),(0x80 | ((c >> 12) & 0x3F)),
				(0x80 | ((c >> 6) & 0x3F)),(0x80 | (c & 0x3F)));
	} else if (c <= 0x3FFFFFF) {                    // 111110xx + 4 
		sprintf(res,"%c%c%c%c%c",(0xF8 | (c >> 24)),(0x80 | ((c >> 18) & 0x3F)),
				(0x80 | ((c >> 12) & 0x3F)),(0x80 | ((c >> 6) & 0x3F)),
				(0x80 | (c & 0x3F)));
	} else if (c <= 0x7FFFFFFF) {                   // 1111110x + 5 
		sprintf(res,"%c%c%c%c%c%c",(0xFC | (c >> 30)),(0x80 | ((c >> 24) & 0x3F)),
				(0x80 | ((c >> 18) & 0x3F)),(0x80 | ((c >> 12) & 0x3F)),
				(0x80 | ((c >> 6) & 0x3F)),(0x80 | (c & 0x3F)));
	} else {                                        // Not a valid character... 
		sprintf(res,"&#%c;", c);
	}
	
	return res;	
}

char* ascii2utf8(char* ascii){
	long n;
	int c;
	int j=0,i=0;
	char* tmp;
	char* res = malloc(strlen(ascii)+100);

	while ( (c =ascii[i++]) != '\0') {

		if (c > 0x7F) {                // Latin-1, non-ASCII 
			tmp=putUTF8(c);
			sprintf(res,"%s%s",res,tmp);
			j += strlen(tmp);
		} else if (c != '&') {          // Normal ASCII char 
			res[j++]=c;
			res[j]='\0';
		} else if ( (c = ascii[i++]) == '\0') { // '&' before EOF
			res[j++]='&';
			res[j]='\0';
		} else if (c != '#') {         // '&' not followed by '#' 
			res[j]='&';
			res[j++]=c;
			res[j]='\0';
		} else if ((c=ascii[i++]) == 'x') {    // '&#x' + hexadecimal 
			n = 0;
			while (isxdigit((c=ascii[i++]))) {
				if (c <= '9') n = 16 * n + c - '0';
				else if (c <= 'F') n = 16 * n + c - 'A' + 10;
				else n = 16 * n + c - 'a' + 10;
			}
			// Don't check for overflow, don't check if c == ';' 
			tmp = putUTF8(n);
			sprintf(res,"%s%s",res,tmp);
			j += strlen(tmp);
		} else {                                        // '&#' + decimal 
			n = c - '0';
			
			while (isdigit((c=ascii[i++])))
				n = 10 * n + c - '0';
			
			// Don't check for overflow, don't check if c == ';' 
			tmp=putUTF8(n);
			sprintf(res,"%s%s",res,tmp);
			j = j + strlen(tmp);
		}
	}
	res[j]='\0';

	return res;
}

/* UIDejunk: remove crap (=html tags) from feed description and convert
 * html entities to something useful if we hit them.
 * This function took almost forever to get right, but at least I learned
 * that html entity &hellip; has nothing to do with Lucifer's ISP, but
 * instead means "..." (3 dots, "and so on...").
 */
char * UIDejunk (char * feed_description) {
	char *start;				// Points to first char everytime. Need to free this. 
	char *text;				// = feed_description.  Well, at least at the beginning of the func. 
	char *newtext;				// Detag'ed *text. 
	char *detagged;				// Returned value from strsep. This is what we want. 
	char *entity;				// Which HTML crap did we hit now? 
	struct entity *cur_entity;
	int found = 0;				// User defined entity matched? 
#ifdef __STDC_ISO_10646__
	wchar_t ch;				// Decoded numeric entity 
	int len;				// Current length of detag'd text 
	int mblen;				// Length of multi-byte entity 
#else
	unsigned long ch;			// Decoded numeric entity 
#endif
	const htmlEntityDesc *ep;	// For looking up HTML entities 
	
	// Gracefully handle passed NULL ptr. 
	if (feed_description == NULL) {
		newtext = strdup("(null)");
		return newtext;
	}
	
	// Make a copy and point *start to it so we can free the stuff again! 
	text = strdup (feed_description);
	start = text;
	
	
	// If *text begins with a tag, discard all of them. 
	while (1) {
		if (text[0] == '<') {
			strsep (&text, "<");
			strsep (&text, ">");
		} else
			break;
		if (text == NULL) {
			newtext = strdup ("No description available.");
			free (start);
			return newtext;
		}
	}
	newtext = malloc (1);
	newtext[0] = '\0';
	
	while (1) {
		// Strip tags... tagsoup mode. 
		// strsep puts everything before "<" into detagged. 
		detagged = strsep (&text, "<");
		if (detagged == NULL)
			break;
		
		// Replace <p> and <br> (in all incarnations) with newlines, but only
		// if there isn't already a following newline. 
		if (text != NULL) {
			if ((strncasecmp (text, "p", 1) == 0) ||
				(strncasecmp (text, "br", 2) == 0)) {
				if ((strncasecmp (text, "br>\n", 4) != 0) &&
					(strncasecmp (text, "br/>\n", 5) != 0) &&
					(strncasecmp (text, "br />\n", 6) != 0) &&
					(strncasecmp (text, "p>\n", 3) != 0)) {
					newtext = realloc (newtext, strlen(newtext)+2);
					strcat (newtext, "\n");
				}
			}
		}
		newtext = realloc (newtext, strlen(newtext)+strlen(detagged)+1);

		// Now append detagged to newtext. 
		strcat (newtext, detagged);
		
		// Advance *text to next position after the closed tag. 
		if ((strsep (&text, ">")) == NULL)
			break;
	}
	free (start);
	
	clean_string (newtext, 0);
	
	// See if there are any entities in the string at all. 
	if (strchr(newtext, '&') != NULL) {
		text = strdup (newtext);
		start = text;
		free (newtext);
	
		newtext = malloc (1);
		newtext[0] = '\0';
		
		while (1) {
			// Strip HTML entities. 
			detagged = strsep (&text, "&");
			if (detagged == NULL)
				break;
			
			if (detagged != '\0') {
				newtext = realloc (newtext, strlen(newtext)+strlen(detagged)+1);
				strcat (newtext, detagged);
			}
			// Expand newtext by one char. 
			newtext = realloc (newtext, strlen(newtext)+2);
			// This might break if there is an & sign in the text. 
			entity = strsep (&text, ";");
			if (entity != NULL) {
				// XML defined entities. 
				if (strcmp(entity, "amp") == 0) {
					strcat (newtext, "&");
					continue;
				} else if (strcmp(entity, "lt") == 0) {
					strcat (newtext, "<");
					continue;
				} else if (strcmp(entity, "gt") == 0) {
					strcat (newtext, ">");
					continue;
				} else if (strcmp(entity, "quot") == 0) {
					strcat (newtext, "\"");
					continue;
				} else if (strcmp(entity, "apos") == 0) {
					strcat (newtext, "'");
					continue;
				}
				
				// Decode user defined entities. 
				found = 0;
				for (cur_entity = first_entity; cur_entity != NULL; cur_entity = cur_entity->next_ptr) {
					if (strcmp (entity, cur_entity->entity) == 0) {
						// We have found a matching entity.
						
						// If entity_length is more than 1 char we need to realloc
						// more space in newtext. 
						if (cur_entity->entity_length > 1)
							newtext = realloc(newtext,strlen(newtext)+cur_entity->entity_length+1);
						
						// Append new entity. 
						strcat (newtext, cur_entity->converted_entity);
						
						// Set found flag. 
						found = 1;
						
						// We can now leave the for loop. 
						break;
					}
				}
								
				// Try to parse some standard entities. 
				if (!found) {
					// See if it was a numeric entity. 
					if (entity[0] == '#') {
						if (entity[1] == 'x')
							ch = strtoul(entity + 2, NULL, 16);
						else
							ch = atol(entity + 1);
					}
					else if ((ep = htmlEntityLookup((xmlChar *)entity)) != NULL)
						ch = ep->value;
					else
						ch = 0;  // Didn't recognize it.

					if (ch > 0) {
#ifdef __STDC_ISO_10646__
						// Convert to locale encoding and append. 
						len = strlen(newtext);
						newtext = realloc(newtext, len + MB_CUR_MAX + 1);
						mblen = wctomb(newtext + len, ch);
						// Only set found flag if the conversion worked. 
						if (mblen > 0) {
							newtext[len + mblen] = '\0';
							found = 1;
						}
#else
						// Since we can't use wctomb(), just convert ASCII. 
						if (ch <= 0x7F) {
							sprintf(newtext + strlen(newtext), "%c", (int)ch);
							found = 1;
						}
#endif
					}
				}

				// If nothing matched so far, put text back in.
				if (!found) {
					// Changed into &+entity to avoid stray semicolons
					// at the end of wrapped text if no entity matches. 
					newtext = realloc (newtext, strlen(newtext)+strlen(entity)+2);
					strcat (newtext, "&");
					strcat (newtext, entity);
				}
			} else
				break;
		}
		free (start);
	}	
	return newtext;
}

/* 5th try at a wrap text functions.
 * My first version was broken, my second one sucked, my third try was
 * so overcomplicated I didn't understand it anymore... Kianga tried
 * the 4th version which corrupted some random memory unfortunately...
 * but this one works. Heureka!
 */

char * WrapText (char * text, int width) {
	char *newtext;
	char *textblob;			// Working copy of text. 
	char *chapter;
	char *line;			// One line of text with max width. 
	char *savepos;			// Saved position pointer so we can go back in the string. 
	char *chunk;
	char *start;
	
	textblob = strdup (text);
	start = textblob;
	

	line = malloc (1);
	line[0] = '\0';
	
	newtext = malloc(1);
	memset (newtext, 0, 1);

	while (1) {
		// First, cut at \n. 
		chapter = strsep (&textblob, "\n");
		if (chapter == NULL)
			break;
		while (1) {
			savepos = chapter;
			chunk = strsep (&chapter, " ");
			
			// Last chunk. 
			if (chunk == NULL) {
				if (line != NULL) {
					newtext = realloc (newtext, strlen(newtext)+strlen(line)+2);
					strcat (newtext, line);
					strcat (newtext, "\n");
					
					// Faster replacement with memcpy.
					// Overkill, overcomplicated and smelling of bugs all over.
					 
					line[0] = '\0';
				}
				break;
			}
			
			if (strlen(chunk) > width) {
				// First copy remaining stuff in line to newtext. 
				newtext = realloc (newtext, strlen(newtext)+strlen(line)+2);
				strcat (newtext, line);
				strcat (newtext, "\n");
				
				free (line);
				line = malloc (1);
				line[0] = '\0';
				
				// Then copy chunk with max length of line to newtext. 
				line = realloc (line, width+1);
				strncat (line, chunk, width-5);
				strcat (line, "...");
				newtext = realloc (newtext, strlen(newtext)+width+2);
				strcat (newtext, line);
				strcat (newtext, "\n");
				free (line);
				line = malloc (1);
				line[0] = '\0';
				continue;
			}

			if (strlen(line)+strlen(chunk) <= width) {
				line = realloc (line, strlen(line)+strlen(chunk)+2);
				strcat (line, chunk);
				strcat (line, " ");
			} else {
				// Why the fuck can chapter be NULL here anyway? 
				if (chapter != NULL) {
					chapter--;
					chapter[0] = ' ';
				}
				chapter = savepos;
				newtext = realloc (newtext, strlen(newtext)+strlen(line)+2);
				strcat (newtext, line);
				strcat (newtext, "\n");
				free (line);
				line = malloc (1);
				line[0] = '\0';
			}
		}
	}
	
	free (line);	
	free (start);	
	
	return newtext;
}

/* Remove leading whitspaces, newlines, tabs.
 * This function should be safe for working on UTF-8 strings.
 * tidyness: 0 = only suck chars from beginning of string
 *           1 = extreme, vacuum everything along the string.
 */
void clean_string (char * string, int tidyness) {
	int len, i;
	
	// If we are passed a NULL pointer, leave it alone and return. 
	if (string == NULL)
		return;
	
	len = strlen(string);
	
	while ((string[0] == '\n' || string [0] == ' ' || string [0] == '\t') &&
			(len > 0)) {
		// len=strlen(string) does not include \0 of string.
		// But since we copy from *string+1 \0 gets included.
		// Delicate code. Think twice before it ends in buffer overflows. 
		memmove (string, string+1, len);
		len--;
	}
	
	// Remove trailing spaces. 
	while ((len > 1) && (string[len-1] == ' ')) {
		string[len-1] = 0;
		len--;
	}
	
	len = strlen(string);
	// Eat newlines and tabs along the whole string. 
	if (tidyness == 1) {
		for (i = 0; i < len; i++) {
			if ((string[i] == '\t') || (string[i] == '\n'))
				string[i] = ' ';
		}
	}
}

// http://foo.bar/address.rdf -> http:__foo.bar_address.rdf 
char * Hashify (const char * url) {
	int i, len;
	char *hashed_url;
	
	hashed_url = strdup(url);
	
	len = strlen(hashed_url);
	
	/* Don't allow filenames > 128 chars for teeny weeny
	 * operating systems.
	 */
	if (len > 128) {
		len = 128;
		hashed_url[128] = '\0';
	}
	
	for (i = 0; i < len; i++) {
		if (((hashed_url[i] < 32) || (hashed_url[i] > 38)) &&
			((hashed_url[i] < 43) || (hashed_url[i] > 46)) &&
			((hashed_url[i] < 48) || (hashed_url[i] > 90)) &&
			((hashed_url[i] < 97) || (hashed_url[i] > 122)) &&
			(hashed_url[i] != 0))
			hashed_url[i] = '_';
	}
	
	return hashed_url;
}

char* bool_to_string(struct feed* feed){
	char* s = NULL;
	bool* read = NULL;
	mrss_item_t* item = NULL;
	int count = 0, i=0;

	read = feed->read;
	item = feed->element->item;

	while(item->next!=NULL){
		count++;
		item=item->next;
	}

	s = malloc(count*sizeof(char));
	item = feed->element->item;
	while(item->next!=NULL){

		if(read[i++])
			s[i-1]='1';
		else
			s[i-1]='0';
		item=item->next;
	}

	return s;
}
