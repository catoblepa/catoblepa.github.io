#include <stdio.h>
#include <ncurses.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <mrss.h>

#include "interface.h"
#include "main.h"
#include "dialog.h"
#include "io-internal.h"
#include "conversions.h"

extern struct keybindings keybindings;

void clear_line (int line, howclearline how) {
	int i;

	if (how == INVERSE)
		attron(WA_REVERSE);
	
	for (i = 0; i < COLS; i++) 
		mvaddch (line, i, ' ');
	
	if (how == INVERSE)
		attron(WA_REVERSE);
}

// Print text in statusbar
void UIStatus (char * text, int delay, int warning) {
	if (warning)
		attron (COLOR_PAIR(10));

	clear_line (LINES-1, INVERSE);
	
	attron (WA_REVERSE);
	mvaddnstr (LINES-1, 1, text, COLS-2);
	
	if (warning)
		attroff (COLOR_PAIR(10));
	attroff (WA_REVERSE);
		
	refresh();
	
	if (delay)
		sleep (delay);
}

// Draw a box with WA_REVERSE at coordinates x1y1/x2y2 
void UISupportDrawBox (int x1, int y1, int x2, int y2) {
	int i, j;
	
	attron (WA_REVERSE);
	for (i = y1; i <= y2; i++) 
		for (j = x1; j <= x2; j++) 
				mvaddch (i, j, ' ');
	
	attroff (WA_REVERSE);
}

char * oneline_entry_field (int x, int y) {
	char *text;

	text = malloc(512);
        
	// UIStatus switches off attron! 
	attron (WA_REVERSE);
	echo();
	curs_set(1);

	move (y, x);
	// Beware of hardcoded textlength size!
	// getnstr size does NOT include \0. This is really stupid and causes
	// 1-byte overflows. Always size=len-1! 
	getnstr (text, 511);

	noecho();
	curs_set(0);
	attroff (WA_REVERSE);

	// This memory needs to be freed in the calling function! 
	return text;
}

void ui_rename_feed (struct feed *cur_ptr) {
	char *newname;
	char *tmp;

	// Clear screen area we want to "draw" to. 
	attron (WA_REVERSE);
	UISupportDrawBox (3, 5, COLS-4, 7);

	UIStatus ("Enter new name. Blank line to abort.", 0, 0);
	
	newname = oneline_entry_field (5, 6);
	
	// If strlen is zero, return 1. 
	if (strlen(newname) == 0) {
		free (newname);
		return;
	}
	
	// If newname contains "|", abort since this is used as a delimiter for the config file. 
	if (strstr (newname, "|") != NULL) {
		free (newname);
		UIStatus ("The new title must not contain a \"|\" character!", 2, 0);
		return;
	}
	
	// Set new title. 
	if(cur_ptr->category){
		free (cur_ptr->category_name);
		tmp = malloc(strlen(newname)+7);
		sprintf(tmp,"== %s ==",newname);
		cur_ptr->category_name = strdup (tmp);
		free(tmp);
	}else{
		free (cur_ptr->feed_name);
		cur_ptr->feed_name = strdup(newname);
	}	
	
	cur_ptr->write_cache=true;

	free (newname);
	
	return;
}

bool exist_feed(char* url){
	struct feed* feed = NULL;
	
	for(feed = first_ptr; feed != NULL; feed = feed->next) {
		if(!feed->category && feed->element->file != NULL && strcmp(url, feed->element->file)==0)
			return true;
	}

	return false;
}

// Popup window to add new RSS feed.
void ui_add_feed(void) {
	char *url;

	// Clear screen area we want to "draw" to. 
	attron (WA_REVERSE);
	UISupportDrawBox (3, 5, COLS-4, 7);

	UIStatus ("Enter URL of the feed you want to add. Blank line to abort.", 0, 0);

	url = oneline_entry_field (5, 6);
	if (strlen(url) == 0) {
		free (url);
		return;
	}
	clean_string(url, 0);

	if( exist_feed(url) ) {
		UIStatus ("The feed already exist!", 1, 1);
		return;
	}
	new_feed(url);

	free(url);
}

int ui_add_category(void) {
	char* category;
	int ret;

	// Clear screen area we want to "draw" to. 
	attron (WA_REVERSE);
	UISupportDrawBox (3, 5, COLS-4, 7);

	UIStatus ("Enter name of category you want to add. Blank line to abort.", 0, 0);

	category = oneline_entry_field (5, 6);

	if (strlen(category) == 0) {
		free (category);
		return 1;
	}
		
	clean_string(category, 0);

	ret = new_category(category);

	if(ret)
		return -1;

	return 0;
}

void FeedInfo (struct feed * current_feed) {
	int centerx, len;
	char *hashme;						// Hashed filename. 
	char *file;
	char *url;							// file - authinfo. 
	struct stat filetest;
	
	url = strdup (current_feed->element->file);
	
	centerx = COLS / 2;
	
	hashme = Hashify(current_feed->element->file);
	len = (strlen(getenv("HOME")) + strlen(hashme) + 18);
	file = malloc (len);
	snprintf (file, len, "%s/.shownews/cache/%s", getenv("HOME"), hashme);

	UISupportDrawBox (5, 4, COLS-6, 13);
	
	attron (WA_REVERSE);
	mvaddstr (5, centerx-((strlen(current_feed->element->title))/2), current_feed->element->title);
	mvaddnstr (7, centerx-(COLS/2-7), url, COLS-14);
	
	if ((stat (file, &filetest)) != -1) 
		mvprintw (9, centerx-(COLS/2-7), "In disk cache: %lld bytes", (long long int) filetest.st_size);
	else
		mvaddstr (9, centerx-(COLS/2-7), "Not in disk cache.");
	

	mvaddstr (10, centerx-(COLS/2-7), current_feed->element->encoding);
	
	UIStatus ("Displaying feed information.", 0, 0);
	
	free (file);
	free (hashme);
	free (url);

	// Wait for the any key. 
	getch();
}

/* delete a category or a feed
 *
 * @parameter: feed struct, feed name (or feed title or category name)
 * @return:
 * 	- the new highlighted feed, may be NULL
 *
 */
struct feed* ui_delete_feed (struct feed* feed, char * feedname) {

	struct feed* highlighted = feed;

	UISupportDrawBox (3, 5, COLS-3, 8);
	
	attron (WA_REVERSE);
	mvaddstr (6, COLS/2-21, "Are you sure you want to delete this feed?");
	mvprintw (7, 5, "%s", feedname);
	
	UIStatus ("Type 'y' to delete, any other key to abort.", 0, 0);
	
	if (getch() == 'y') {

		// Remove cache file
		if(!highlighted->category && highlighted->element->file!=NULL)
			clean_cache(highlighted->element->file);

		// Unlink pointer from list
		if (feed == first_ptr) { // First feed
	
			if(feed->next == NULL){
				first_ptr = NULL;
				highlighted = NULL;
			} else {
				UIStatus("qua",1,0);
				first_ptr = feed->next;
				feed->next->prev = NULL;
				highlighted = feed->next;
			}
			

		} else if (feed->next == NULL){ // Last feed
			
			feed->prev->next=NULL;
			highlighted = feed->prev;
		
		} else { // Normal element

			feed->prev->next = feed->next;
			feed->next->prev = feed->prev;

			highlighted=feed->next;
		}

		freefeedstruct(feed);
	}
	
	return highlighted;
}


void ui_main_help (void) {
	int centerx, centery;				// Screen center x/y coordinate. 
	int userinput;
	int offset = 18;
	int offsetstr = 12;
	
	centerx = COLS / 2;
	centery = LINES / 2;
	
	UISupportDrawBox ((COLS/2)-20, (LINES/2)-6, (COLS/2)+24, (LINES/2)+6);
	
	attron (WA_REVERSE);
	// Keys 
	mvprintw (centery-5, centerx-offset, "%c:", keybindings.addfeed);	
	mvprintw (centery-4, centerx-offset, "%c:", keybindings.deletefeed);
	mvprintw (centery-3, centerx-offset, "%c:", keybindings.changefeedname);
	mvprintw (centery-2, centerx-offset, "%c:", keybindings.reloadall);
	mvprintw (centery-1, centerx-offset, "%c:", keybindings.reload);
	mvprintw (centery, centerx-offset, "%c:", keybindings.forcereload);
	mvprintw (centery+1,   centerx-offset, "%c:", keybindings.markread);
	mvprintw (centery+2, centerx-offset, "%c:", keybindings.markunread);
	mvprintw (centery+3, centerx-offset, "%c, %c:", keybindings.moveup, keybindings.movedown);
	mvprintw (centery+4, centerx-offset, "%c:", keybindings.categorize);
	mvprintw (centery+5, centerx-offset, "%c:", keybindings.quit);
	// Descriptions 
	mvaddstr (centery-5, centerx-offsetstr, "Add RSS feed");
	mvaddstr (centery-4, centerx-offsetstr, "Delete highlighted RSS feed");
	mvaddstr (centery-3, centerx-offsetstr, "Rename feed or category");
	mvaddstr (centery-2, centerx-offsetstr, "Reload all feeds");
	mvaddstr (centery-1, centerx-offsetstr, "Reload this feed");
	mvaddstr (centery, centerx-offsetstr, "Force reload this feed from net");
	mvaddstr (centery+1,   centerx-offsetstr, "Mark feed as read");
	mvaddstr (centery+2, centerx-offsetstr, "Mark feed as unread");
	mvaddstr (centery+3, centerx-offsetstr, "Move item up, down");
	mvaddstr (centery+4, centerx-offsetstr, "Add category");
	mvaddstr (centery+5, centerx-offsetstr, "Quit program");
	attroff (WA_REVERSE);

	UIStatus ("Press the any(tm) key to exit help screen.", 0, 0);
	userinput = getch();
	
	// Return input back into input queue so it gets automatically  executed. 
	if ((userinput != '\n') && (userinput != 'h') && (userinput != 'q'))
		ungetch(userinput);
}


void ui_feed_help (void) {
	int centerx, centery;				// Screen center x/y coordinate. 
	int userinput;
	int offset = 18;
	int offsetstr = 7;
	
	centerx = COLS / 2;
	centery = LINES / 2;
	
	UISupportDrawBox ((COLS/2)-20, (LINES/2)-5, (COLS/2)+24, (LINES/2)+4);
	
	attron (WA_REVERSE);
	// Keys 
	mvprintw (centery-4, centerx-offset, "up:");	
	mvprintw (centery-3, centerx-offset, "down:");
	mvaddstr (centery-2, centerx-offset, "enter:");
	mvprintw (centery-1, centerx-offset, "%c:", keybindings.urljump);
	mvprintw (centery,   centerx-offset, "%c:", keybindings.markread);
	mvprintw (centery+1, centerx-offset, "%c:", keybindings.markunread);
	mvprintw (centery+2, centerx-offset, "%c:", keybindings.feedinfo);
	mvprintw (centery+3, centerx-offset, "%c:", keybindings.prevmenu);
	// Descriptions 
	mvprintw (centery-4, centerx-offsetstr, "Previous item");	
	mvprintw (centery-3, centerx-offsetstr, "Next item");
	mvaddstr (centery-2, centerx-offsetstr, "View item");
	mvprintw (centery-1, centerx-offsetstr, "Open link");
	mvprintw (centery,   centerx-offsetstr, "Mark item read");
	mvprintw (centery+1, centerx-offsetstr, "Mark item unread");
	mvprintw (centery+2, centerx-offsetstr, "Show feed info");
	mvprintw (centery+3, centerx-offsetstr, "Return to main menu");
	attroff (WA_REVERSE);

	UIStatus ("Press the any(tm) key to exit help screen.", 0, 0);
	userinput = getch();
	if ((userinput != '\n') && (userinput != 'h'))
		ungetch(userinput);
}

void ui_item_help (void) {
	int centerx, centery;				// Screen center x/y coordinate. 
	int userinput;
	int offset = 16;
	int offsetstr = 6;
	
	centerx = COLS / 2;
	centery = LINES / 2;
	
	UISupportDrawBox ((COLS/2)-18, (LINES/2)-2, (COLS/2)+18, (LINES/2)+3);
	
	attron (WA_REVERSE);
	// Keys 
	mvprintw (centery-1, centerx-offset, "<-:");	
	mvprintw (centery,   centerx-offset, "->:");
	mvprintw (centery+1, centerx-offset, "%c:", keybindings.urljump);
	mvprintw (centery+2, centerx-offset, "%c, enter:", keybindings.prevmenu);
	// Descriptions 
	mvaddstr (centery-1, centerx-offsetstr, "Previous item");	
	mvaddstr (centery,   centerx-offsetstr, "Next item");
	mvaddstr (centery+1, centerx-offsetstr, "Open link");
	mvaddstr (centery+2, centerx-offsetstr, "Return to overview");
	attroff (WA_REVERSE);

	UIStatus ("Press the any(tm) key to exit help screen.", 0, 0);
	userinput = getch();
	if ((userinput != '\n') && (userinput != 'h'))
		ungetch(userinput);
}
