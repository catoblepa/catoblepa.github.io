#ifndef MAIN_H
#define MAIN_H

#define DEFAULT_BROWSER "firefox"
#define DEFAULT_TIMEOUT 15


#include <stdbool.h>
#include <libintl.h>
#include <locale.h>

bool autoload;
char* browser;
int time_out;
void main_quit(char* msg, char* func);
void load_config(void);
void init_curses(void);

struct feed {
	struct feed *next, *prev;
	struct mrss_t *element;
	bool  write_cache;
	bool* read;
	bool  category;
	char* category_name;
	char* feed_name;
};

struct keybindings {
	char next;
	char prev;
	char prevmenu;
	char quit;
	char addfeed;
	char deletefeed;
	char markread;
	char markunread;
	char moveup;
	char movedown;
	char feedinfo;
	char reload;
	char forcereload;
	char reloadall;
	char urljump;
	char changefeedname;
	char categorize;
	char help;
	char export_opml;
};

struct color {
	int newitems;
	int urljump;
	int feedtitle;
};

extern struct feed *first_ptr;

#endif
