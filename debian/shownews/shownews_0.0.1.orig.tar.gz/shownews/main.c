#include <ncurses.h>
#include <libgen.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <signal.h>
#include <sys/wait.h>

#include "interface.h"
#include "main.h"
#include "io-internal.h"
#include "dialog.h"

#define VERSION "0.0.1"

bool autoload = true;
char* browser = NULL;
int time_out = DEFAULT_TIMEOUT;

struct feed *first_ptr = NULL;
struct entity *first_entity = NULL;

struct keybindings keybindings;
struct color color;


void init_curses(void){
	initscr();
	keypad(stdscr,TRUE); 	// Activate keypad

	cbreak();		// No buffering
	noecho();		// Do not echo
	clear();
	curs_set(0);		// Hide cursor
	refresh();
}

void setup_keys (void) {
	keybindings.next = 'n';
	keybindings.prev = 'p';
	keybindings.prevmenu = 'q';
	keybindings.quit = 'q';
	keybindings.addfeed = 'a';
	keybindings.deletefeed = 'D';
	keybindings.markread = 'm';
	keybindings.markunread = 'M';
	keybindings.moveup = 'P';
	keybindings.movedown = 'N';
	keybindings.feedinfo = 'i';
	keybindings.reload = 'r';
	keybindings.forcereload = 'f';
	keybindings.reloadall = 'R';
	keybindings.urljump = 'o';
	keybindings.changefeedname = 'c';
	keybindings.categorize = 'C';
	keybindings.help = 'h';
	keybindings.export_opml = 'e';
}

void setup_colors (void) {
	
	color.newitems = 5;
	color.urljump = 4;
	color.feedtitle = -1;
	
	start_color();
		
	// The following call will automagically implement -1 as the terminal's default color for fg/bg in init_pair. 
	use_default_colors();
		
	// Internally used color pairs. Use with WA_BOLD to get bright color (orange->yellow, gray->white, etc). 
	init_pair (10, 1, -1);		// red 
	init_pair (11, 2, -1);		// green 
	init_pair (12, 3, -1);		// orange 
	init_pair (13, 4, -1);		// blue 
	init_pair (14, 5, -1);		// magenta 
	init_pair (15, 6, -1);		// cyan 
	init_pair (16, 7, -1);		// gray 
	
	// Default terminal color color pair 
	init_pair (63, -1, -1);
	
	init_pair (2, color.newitems, -1);
	init_pair (3, color.urljump, -1);
	init_pair (4, color.feedtitle, -1);
}

//Create and load configuraton file
void load_config (void) {
	char file[512];
	char filebuf[4096];
	char *freeme, *tmpbuf, *tmpstr;
	FILE *configfile;
	struct stat dirtest;
	char* url;
	
	struct feed* new_feed;
	
	
	// Set umask to 077 for all created files.
	umask(63);

	snprintf (file, sizeof(file), "%s/.shownews", getenv("HOME"));
	if ((stat (file, &dirtest)) == -1 ) {
		if (mkdir (file, S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH) != 0)
			main_quit ("Creating config directory ~/.shownews/", strerror(errno));
	} else {
		if ((dirtest.st_mode & S_IFDIR) != S_IFDIR) 
			main_quit ("Creating config directory ~/.shownews/",
				  "A file with the name \"~/.shownews\" exists!");
	}
	
	snprintf (file, sizeof(file), "%s/.shownews/cache", getenv("HOME"));
	if ((stat (file, &dirtest)) == -1) {
		if (mkdir (file, S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH) != 0)
		 	main_quit ("Creating config directory ~/.shownews/cache/", strerror(errno));
	} else {
		if ((dirtest.st_mode & S_IFDIR) != S_IFDIR) 
			main_quit ("Creating config directory ~/.shownews/cache/",
				  "A file with the name \"~/.shownews/cache/\" exists!");
	}	
	
	UIStatus ("Reading configuration settings...", 0, 0);
	
	snprintf (file, sizeof(file), "%s/.shownews/urls", getenv("HOME"));
	configfile = fopen (file, "r");
	if (configfile == NULL) {
		UIStatus ("Creating new configfile.", 0, 0);

		configfile = fopen (file, "w+");
		if (configfile == NULL)
		 	main_quit ("Create initial configfile \"urls\"", strerror(errno)); 

	} else {
		
		while (!feof(configfile)) {
			if ((fgets (filebuf, sizeof(filebuf), configfile)) == NULL)
				break;
			if (filebuf[0] == '\n')
				break;
		
			// File format is url|read news|feed name 
			tmpbuf = strdup (filebuf);
			
			if (tmpbuf[strlen(tmpbuf)-1] == '\n')
				tmpbuf[strlen(tmpbuf)-1] = '\0';
				
			freeme = tmpbuf;
			tmpstr = strsep (&tmpbuf, "|");
			
			url = strdup(freeme);
			
			if(url[0]=='=' && url[1]=='=') {
				new_feed = load_category(url);
			} else {
				tmpstr = strsep (&tmpbuf, "|");
				
				new_feed = load_feed(url,tmpstr);

				free (freeme);
			}
			tmpstr = strsep(&tmpbuf, "|");

			if(tmpstr!=NULL )
				new_feed->feed_name = strdup(tmpstr);
				
			// Add to bottom of pointer chain. 
			new_feed->next = NULL;
			if (first_ptr == NULL) {
				new_feed->prev = NULL;
				first_ptr = new_feed;
			} else {
				new_feed->prev = first_ptr;
				
				while (new_feed->prev->next != NULL)
					new_feed->prev = new_feed->prev->next;

				new_feed->prev->next = new_feed;
			}
		}
		autoload=true;
	}

	fclose (configfile);

	setup_colors();
	setup_keys();
}


// De-init ncurses and quit.
void main_quit (char* func, char* error) 
{
	// Save settings only if no-error occours!
	if(error==NULL)
		write_cache();
	
	clear();
	refresh();
	endwin(); 
	
	free(browser);

	if (!error) {	
		exit(EXIT_SUCCESS);
	} else {
		fprintf (stderr, "Error '%s' while executing '%s'\n", error, func);
		fprintf (stderr, "Aborting program execution! An internal error occured.\n");
		fprintf (stderr, "Shownews has quit and no changes has been saved!\n");
		
		exit(EXIT_FAILURE);
	}
}

/* Signal handler function. */
void main_signal_handler (int sig) {
	main_quit("","User abort");
}

void help_message(const char* execname) {
	printf("\n%s version "VERSION"\n\n"
		"usage: %s [-b browser] [-n] [-h] [-v] [-t timeout]\n\n"
		"\t-b browser\tUse custom browser to see the news\n"
		"\t-n\tNot update every feed on startup.\n"
		"\t-h\tPrint this help message and exit.\n"
		"\t-t timeout\tSet the timeout to download feed (default 15 sec.).\n"
		"\t-v\tPrint version number and exit.\n\n",execname,execname);

	return;
}

int main (int argc, char **argv) {

	int ch = 0;
	
	setlocale (LC_ALL, "");

	// command line parser
	while ((ch = getopt(argc, argv, "b:nvht:")) != -1) {
		switch (ch) {
			case 't':
				time_out = atoi(optarg);
				break;

			case 'b':
				browser = optarg;
				break;
			case 'n':
				autoload = false;
				break;
			
			case 'v':
				printf(VERSION"\n");
				return EXIT_SUCCESS;

			case 'h':
			default:
				help_message(basename(argv[0]));
				return EXIT_SUCCESS;
		}
	}

	if(browser==NULL)
		browser = strdup(DEFAULT_BROWSER);

	signal (SIGHUP, main_signal_handler);
	signal (SIGINT, main_signal_handler);
	signal (SIGTERM, main_signal_handler);
	signal (SIGPIPE, SIG_IGN);

	init_curses();
	
	load_config();
	
	// Give control to main program loop. 
	main_interface();

	// We really shouldn't be reach this point!
	main_quit(NULL, NULL);
	
	return 0;
}
