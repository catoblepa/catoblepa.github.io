#ifndef CONVERSIONS_H
#define CONVERSIONS_H

char* bool_to_string(struct feed* feed);
char * UIDejunk (char * feed_description);
char * WrapText (char * text, int width);
void clean_string (char * string, int tidyness);
char * Hashify (const char * url);
char * genItemHash (char ** hashitems, int items);
char * unixToPostDateString (int unixDate);
char* ascii2utf8(char* ascii);

struct entity {
	char * entity;
	char * converted_entity;
	int entity_length;
	struct entity * next_ptr;
};


#endif
