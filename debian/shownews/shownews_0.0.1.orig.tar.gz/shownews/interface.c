#include <ncurses.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>

#include "main.h"
#include "interface.h"
#include "conversions.h"
#include "dialog.h"
#include "io-internal.h"

extern struct keybindings keybindings;
extern struct color color;

// Scrollable feed->description. 
struct scrolltext {
	char * line;
	struct scrolltext * next_ptr;
	struct scrolltext * prev_ptr;
};

// strcasestr stolen from: http://www.unixpapa.com/incnote/string.html
char *s_strcasestr(char *a, char *b) {
	size_t l;
	char f[3];
	int lena = strlen(a);
	int lenb = strlen(b);

	snprintf(f, sizeof(f), "%c%c", tolower(*b), toupper(*b));
	for (l = strcspn(a, f); l != lena; l += strcspn(a + l + 1, f) + 1)
		if (strncasecmp(a + l, b, lenb) == 0)
			return(a + l);
	return(NULL);
}

void display_footer(){
	char tmpstr[74];

	snprintf (tmpstr,74,"Press '%c' or Enter to return to previous screen. Hit '%c' for help screen.",
			keybindings.prevmenu, keybindings.help);
	UIStatus (tmpstr, 0, 0);
}

void display_link(char* link){
	// Apply color style. 
	attron (COLOR_PAIR(3));
		
	// Print feed URL. 
	if (link == NULL)
		mvaddstr (LINES-2, 1, "-> No link");
	else
		mvprintw (LINES-2, 1, "-> %s", link);
		
	// Disable color style. 
	attroff (COLOR_PAIR(3));
}

// View newsitem in scrollable window.
void display_item (struct mrss_item_t* current_item, struct feed* current_feed, int highlightnum) {
	
	int maxlines = 0;
	char *textslice;
	char *freeme;					// str pos pointer. 
	char *newtextwrapped;
	int linenumber = 0;				// First line on screen (scrolling). Ugly hack. 
	int i,j;
	struct scrolltext *textlist = NULL;
	struct scrolltext *cur_ptr = NULL;
	struct scrolltext *tmp_ptr = NULL;
	struct scrolltext *next_ptr = NULL;
	struct scrolltext *first_ptr = NULL;
	int uiinput;
	int columns;
	int ypos;
	int rewrap;						// Set to 1 if text needs to be rewrapped. 

	// Activate rewrap. 
	rewrap = 1;
	
	while (1) {
	
		// Mark as read
		current_feed->read[highlightnum-1] = true;

		move (0, 0);
		clrtobot();
				
		ypos = 6;
		
		// If feed doesn't have a description print title instead. 
		attron (WA_BOLD);
		columns = COLS-10;
		if (current_feed->element->description != NULL) {
			// Define columns, because malloc three lines down might fail
			// and corrupt mem while resizing the window. 

			mvaddnstr (1, 1, current_feed->element->description, columns);
			if (strlen (current_feed->element->description) > columns)
				mvaddstr (2, columns+1, "...");
				
		} else {
			mvaddstr (1, 1, current_feed->element->title);
		}
		
		attroff (WA_BOLD);

		//If we have an image... show it!
		//TODO
		
		// Print publishing date if we have one. 
		move (LINES-3, 0);
		clrtoeol();

		if (current_item->pubDate != 0) {
			attron(WA_BOLD);
			mvaddstr(LINES-3, 2, current_item->pubDate);
			attroff(WA_BOLD);
		}
		
		// Don't print feed titles longer than screenwidth here.
		// columns is needed to avoid race conditions while resizing the window. 
		columns = COLS-6;
		// And don't crash if title is empty. 
		attron(WA_BOLD);
		attron (COLOR_PAIR(11));
		if (current_item->title != NULL) {
			
			if(strlen(current_item->title)>columns){
				mvaddnstr (4, 1, current_item->title, columns);
				if (strlen(current_item->title) > columns)
					mvaddstr (4, columns+1, "...");
			}
			else
				mvprintw (4, (COLS/2)-(strlen(current_item->title)/2), "%s", current_item->title);
		} else
			mvaddstr (4, (COLS/2)-(strlen("No title"))/2, "No title");
		
		attroff(WA_BOLD);
		attroff (COLOR_PAIR(11));

		if (current_item->description == NULL)
			mvprintw (6, 1, "No description available.");
		else {
			if (strlen(current_item->description) == 0)
				mvprintw (6, 1, "No description available.");
			else {
				// Only generate a new scroll list if we need to rewrap everything.
				if (rewrap) {
				
					newtextwrapped = WrapText (current_item->description, COLS-4);
					freeme = newtextwrapped;	// Set ptr to str start so we can free later. 
					
					// Split newtextwrapped at \n and put into double linked list.
					while (1) {
						textslice = strsep (&newtextwrapped, "\n");
						
						// Find out max number of lines text has. 
						maxlines++;
						
						if (textslice != NULL) {
							textlist = malloc (sizeof(struct scrolltext));
							
							textlist->line = strdup(textslice);
							
							// Gen double list with new items at bottom. 
							textlist->next_ptr = NULL;
							if (first_ptr == NULL) {
								textlist->prev_ptr = NULL;
								first_ptr = textlist;
							} else {
								textlist->prev_ptr = first_ptr;
								while (textlist->prev_ptr->next_ptr != NULL)
									textlist->prev_ptr = textlist->prev_ptr->next_ptr;
								textlist->prev_ptr->next_ptr = textlist;
							}
						} else
							break;
					}
				
					free (freeme);
					rewrap = 0;
				}
				
				j = linenumber;
				// We sould now have the linked list setup'ed... hopefully. 
				for (cur_ptr = first_ptr; cur_ptr != NULL; cur_ptr = cur_ptr->next_ptr) {
					// Skip lines we don't need to display. 
					if (j > 0) {
						j--;
						continue;
					}
					if (ypos > LINES-4)
						continue;
					mvaddstr (ypos, 2, cur_ptr->line);
					ypos++;
				}
			}
		}
	
		display_link(current_item->link);
		
		// user input	
		uiinput = getch();
		
		// Help
		if (uiinput == keybindings.help)
			ui_item_help();
	
		// Quit
		if (uiinput == 'q') {
			// Free the wrapped text linked list.
			for (cur_ptr = first_ptr; cur_ptr != NULL; cur_ptr = next_ptr) {
				tmp_ptr = cur_ptr;
				if (cur_ptr->next_ptr != NULL)
					first_ptr = cur_ptr->next_ptr;
				free (tmp_ptr->line);
				next_ptr = cur_ptr->next_ptr;
				free (tmp_ptr);
			}
			
			return;
		}
		
		// Browser
		if (uiinput == keybindings.urljump)
			launch_browser (current_item->link);
	
		// Right
		if (uiinput == KEY_RIGHT) {
			if (current_item->next != NULL) {
				current_item = current_item->next;
				linenumber = 0;
				rewrap = 1;
				maxlines = 0;
				highlightnum++;
			} 
		}
		
		// Left
		if (uiinput == KEY_LEFT) {
			int j;
			if(highlightnum!=1){
				current_item = current_feed->element->item;
				for(j=1;j<highlightnum-1;j++)
					current_item = current_item->next;
		
				linenumber = 0;
				rewrap = 1;
				maxlines = 0;
				highlightnum--;
			} 
		}
		
		// Page down
		if (uiinput == KEY_NPAGE) {
			for (i = 0; i < LINES-9; i++) {
				if (linenumber+(LINES-7) < maxlines)
					linenumber++;
			}
		}

		// Page up
		if (uiinput == KEY_PPAGE) {
			for (i = 0; i < LINES-9; i++) {
				if (linenumber >= 1)
					linenumber--;
			}
		}

		// Up
		if (uiinput == KEY_UP) {
			if (linenumber >= 1)
				linenumber--;
		}

		// Down
		if (uiinput == KEY_DOWN) {
			if (linenumber+(LINES-7) < maxlines)
				linenumber++;
		}
		
		/*if (uiinput == KEY_RESIZE) {
			rewrap = 1;
			// Reset maxlines, otherwise the program will scroll to far down. 
			maxlines = 0;
		}*/
		
		// Redraw screen on ^L 
		if (uiinput == 12)
			clear();
		
		// Free the linked list structure if we need to rewrap the text block. 
		if (rewrap) {
			// Free textlist list before we start loop again. 
			for (cur_ptr = first_ptr; cur_ptr != NULL; cur_ptr = next_ptr) {
				tmp_ptr = cur_ptr;
				if (cur_ptr->next_ptr != NULL)
					first_ptr = cur_ptr->next_ptr;
				free (tmp_ptr->line);
				next_ptr = cur_ptr->next_ptr;
				free (tmp_ptr);
			}
			// first_ptr must be set to NULL again!
			// = back to init value. 
			first_ptr = NULL;
		}
		
	}

}

void display_feed_menu(struct feed* current_feed, int first_screen_item_num, int highlighted_num) {

	bool forceredraw = false;

	int columns;
	int itemnum;
	int i, ypos;
	int uiinput = 0;
	int feed_num = highlighted_num;
	int num;

	struct mrss_item_t* curitem_ptr;
	struct mrss_item_t* first_screen_item = current_feed->element->item;
	struct mrss_item_t* highlighted = current_feed->element->item;
	
	for(i=1; i<first_screen_item_num; i++)
		first_screen_item = first_screen_item->next;

	for(i=1; i<highlighted_num; i++)
		highlighted = highlighted->next;
	
	while (1) {
		if (forceredraw) {
			clear();
			forceredraw = false;
		} else {
			move (0, 0);
			clrtobot();
		}
		
		attron (WA_BOLD);
		
		if (current_feed->element->description != NULL) {
			// Print a max of COLS-something chars.
			// This function might cause overflow if user resizes screen
			// during malloc and strncpy. To prevent this we use a private
			// columns variable. 
			columns = COLS-10;
			
			mvaddnstr (1, 1, current_feed->element->description, columns);
			if (strlen (current_feed->element->description) > columns)
				mvaddstr(1, columns+1, "...");
			
		} else {
			mvprintw (1, 1,	"%s", current_feed->element->title);
		}
		
		attroff (WA_BOLD);
		
		// We start the item list at line 3. 
		ypos = 3;
		itemnum = 1;
		columns = COLS-6;			// Cut max item length. 
		
		// Print unread entries in bold. 
		for (curitem_ptr = first_screen_item; curitem_ptr != NULL; curitem_ptr = curitem_ptr->next) {
			// Set cursor to start of current line and clear it. 
			move (ypos, 0);
			clrtoeol();
			
			if(!current_feed->read[first_screen_item_num-1+itemnum-1]) 
				attron (COLOR_PAIR(2));

			if (curitem_ptr == highlighted) {
				move (ypos, 0);
				highlighted_num = itemnum;
				attron (WA_REVERSE);
				for (i = 0; i < COLS; i++)
					mvaddch (ypos, i, ' ');
			}

                        /* Check for empty <title> */
			if (curitem_ptr->title != NULL)
				mvaddnstr (ypos, 1, curitem_ptr->title, columns);
			else
				mvaddstr (ypos, 1, "No title");

			ypos++;
		
			if (curitem_ptr == highlighted)
				attroff (WA_REVERSE);
	
			if(!current_feed->read[first_screen_item_num-1+itemnum-1]) 
				attroff (COLOR_PAIR(2));
		
			if (itemnum >= LINES-7)
				break;
			itemnum++;
		}

		display_link(current_feed->element->link);

		//Display foot message
		display_footer();
			
		//User Input
		uiinput = getch();
	
		//Exit
		if (uiinput == keybindings.prevmenu) 
			return;

		// If no item <-- Alway under Exit
		if (highlighted==NULL) 
			continue;
		
		//Page Down
		if (uiinput == KEY_NPAGE) {
			for (i=1; i<=5; i++) {
				if(highlighted->next!=NULL){
					highlighted = highlighted->next;
					highlighted_num++;	

					if (highlighted_num+1 > LINES-7) {
						// Fell off screen. 	
						first_screen_item = first_screen_item->next;
						first_screen_item_num++;
					}
					
					feed_num++;
				} else {
					break;
				}
			}
		}
		
		//Page Up
		if (uiinput == KEY_PPAGE) {
			highlighted = current_feed->element->item;
			highlighted_num=1;
			first_screen_item = current_feed->element->item;
			first_screen_item_num=1;

			for(i=1; i<feed_num-5; i++) {

				highlighted = highlighted->next;
				highlighted_num++;
				
				if (highlighted_num-1 < 1) {
					// Fell off screen. 	
					first_screen_item = highlighted;
					first_screen_item_num++;
				}
				
				if(highlighted == current_feed->element->item)
					break;
			}
			feed_num-=5;
			if(feed_num<1)
				feed_num=1;
		}

		//Up
		if (uiinput == KEY_UP) {
			highlighted=current_feed->element->item;
			if(feed_num>1){
				num=1;
					
				while(num!=feed_num-1) {
					highlighted = highlighted->next;
					num++;
				}
				
				if (highlighted_num-1 < 1) {
					first_screen_item = highlighted;
					first_screen_item_num--;
				}

				feed_num--;
			}
		}

		

		//Down
		if (uiinput == KEY_DOWN){
			if(highlighted->next!=NULL){
				highlighted = highlighted->next;
				
				if (highlighted_num+1 > LINES-7) {
					// Fell off screen. 	
					first_screen_item = first_screen_item->next;
					first_screen_item_num++;
				}
				feed_num++;
			}
		}
	
		//Home
		if (uiinput == KEY_HOME){
			highlighted = current_feed->element->item;
			first_screen_item = current_feed->element->item;
			first_screen_item_num=1;
			feed_num=1;
		}
		
		//End
		if (uiinput == KEY_END){
			while (highlighted->next != NULL) {
				highlighted = highlighted->next;
				feed_num++;
				highlighted_num++;
				if (highlighted_num+1 > LINES-6 && first_screen_item->next != NULL){
						first_screen_item = first_screen_item->next;
						first_screen_item++;
				}
			}
		}
		
		//Enter
		if (uiinput == '\n') {
			display_item (highlighted, current_feed, highlighted_num);
				
			// Moves highlight to next unread item. 
			/*while (highlighted->next != NULL) {
				if(current_feed->read[highlighted_num-1]) {
					highlighted = highlighted->next;
					highlighted_num++;
					feed_num++;

					if (highlighted_num+1 > LINES-7) {
						first_screen_item = first_screen_item->next;
						first_screen_item_num++;
					}	
				} else {
					break;		
				}
			}
			
			// Non more unread
			if(current_feed->read[highlighted_num-1]) {
				highlighted = first_screen_item = current_feed->element->item;
				first_screen_item_num = highlighted_num = 1;
				feed_num=1;
			}*/	
		}

		//Go to url
		if (uiinput == keybindings.urljump)
			launch_browser (current_feed->element->link);
		
		//Mark read
		if (uiinput == keybindings.markread){ 
			current_feed->read[feed_num-1]=true;

			while (highlighted->next != NULL) {
				if(current_feed->read[highlighted_num-1]) {
					highlighted = highlighted->next;
					highlighted_num++;
					feed_num++;

					if (highlighted_num+1 > LINES-7) {
						first_screen_item = first_screen_item->next;
						first_screen_item_num++;
					}	
				} else {
					break;		
				}
			}
			
			// Non more unread
			if(current_feed->read[highlighted_num-1]) {
				highlighted = first_screen_item = current_feed->element->item;
				first_screen_item_num = highlighted_num = 1;
				feed_num=1;
			}	
		}
			
		//Mark unread
		if (uiinput == keybindings.markunread) 
			current_feed->read[feed_num-1]=false;

		//Feed info
		if (uiinput == keybindings.feedinfo)
			FeedInfo(current_feed);

		//Help
		if (uiinput == keybindings.help)
			ui_feed_help();

		// Redraw screen on ^L 
		if (uiinput == 12)
			forceredraw = true;

	}
}

void display_feed (struct feed* current_feed) {

	struct mrss_item_t* highlighted;
	int highlighted_num = 1; 	//highlight feed number
	int first_screen_item_num = 1; 	// First feed screen number.

	if(current_feed->element->item==NULL)
		return;

	highlighted = current_feed->element->item;

	// Moves highlight to the first unread item. 
	while (highlighted->next != NULL) {
		if(current_feed->read[highlighted_num-1]){
			highlighted = highlighted->next;
			highlighted_num++;
			// Fell off screen. 
			if (highlighted_num+1 > LINES-7)	
				first_screen_item_num++;
		} else {
			break;				
		}
	}

	//No more unread, highlight the first item!
	if(current_feed->read[highlighted_num-1])
		highlighted_num = first_screen_item_num = 1;

	display_feed_menu(current_feed,first_screen_item_num,highlighted_num);
}


void main_interface (void) {
	
	struct feed* first_screen_feed = first_ptr;	// First pointer on top of screen. Used for scrolling. 
	struct feed* highlighted = first_ptr;
	struct feed* feed_ptr;

	struct mrss_item_t* curitem_ptr;
	
	int ypos;
	int itemnum;			// Num of items on screen. Max is LINES-4 
	int count;
	int highlightnum = 1;
	int i,j;
	int columns;
	int new_item_number;					// Number of new articles. 
	int uiinput;
	int pos_num = 1;

	char* tmp;

	clear();

	while (1) {

		move (0,0);
		clrtobot();

		ypos = 1;
		itemnum = 1;
		for (feed_ptr = first_screen_feed; feed_ptr != NULL; feed_ptr = feed_ptr->next) {
			// Set cursor to start of current line and clear it. 
			move (ypos, 0);
			clrtoeol();
			
			// Determine number of new items in feed. 
			new_item_number = 0;
			count = 0;
			if(feed_ptr->element!=NULL){ 
				j=0;
				for (curitem_ptr=feed_ptr->element->item; curitem_ptr!=NULL; curitem_ptr=curitem_ptr->next) {
			        	if(!feed_ptr->read[j++])
						new_item_number++;	
					count++;
				}
			} 

			// Make highlight if we are the highlighted feed 
			if (feed_ptr == highlighted) {
				move (ypos, 0);
				highlightnum = itemnum;
				attron (WA_REVERSE);
				for (i = 0; i < COLS; i++)
					mvaddch (ypos, i, ' ');
			}
				
			columns = COLS-9-strlen("new");

			if(feed_ptr->category){
				attron (COLOR_PAIR(10));
				mvaddnstr (ypos, 1, feed_ptr->category_name, columns);
				attroff (COLOR_PAIR(10));
			} else {
				if(new_item_number!=0)
					attron (COLOR_PAIR(11));

				if(feed_ptr->feed_name==NULL)
					mvaddnstr (ypos, 1, feed_ptr->element->title, columns);
				else
					mvaddnstr (ypos, 1, feed_ptr->feed_name, columns);

				if(new_item_number!=0)
					attroff (COLOR_PAIR(11));
			}
			
			// Execute this _after_ the for loop. Otherwise it'll suck CPU like crazy! 
			if (new_item_number != 0) {
				tmp = malloc(9);
				snprintf(tmp, 9, "(%i/%i)", new_item_number, count);
				mvaddstr (ypos, COLS-1-strlen(tmp), tmp);
				free(tmp);
			}
			ypos++;
			
			if (feed_ptr == highlighted)
				attroff (WA_REVERSE);
			
			if (itemnum >= LINES-4)
				break;
			
			itemnum++;
		}
		
		tmp = malloc(27);
		snprintf (tmp, 27, "Press '%c' for help window.", keybindings.help);
		UIStatus (tmp, 0, 0);
		free(tmp);

		//User input
		uiinput = getch();
	
		// Exit
		if (uiinput == keybindings.quit) 
			main_quit (NULL, NULL);

		// Add feed
		if (uiinput == keybindings.addfeed) {
			ui_add_feed();
		
			if(first_ptr!=NULL){
				highlighted = first_ptr;
				first_screen_feed = first_ptr;
			
				for(i = 0; i<pos_num; i++){
					if (highlighted->next != NULL) {
						swap_pointers (highlighted, highlighted->next);
						highlighted = highlighted->next;
						if (highlightnum+1 > LINES-4)
							first_screen_feed = first_screen_feed->next;
					}
				}
				pos_num++;
			}

		}
	
		// Add category
		if (uiinput == keybindings.categorize){ 
		
			ui_add_category();
		
			highlighted = first_ptr;
			first_screen_feed = first_ptr;

			pos_num = 1;
		}
	
		// Help
		if (uiinput == keybindings.help)
			ui_main_help();

		// If no feed <-- Always under "Exit", "Help" & "Add"
		if (highlighted==NULL) 
			continue;
		
		// Export opml
		if (uiinput == keybindings.export_opml){
			export_opml(first_ptr);
		}

		// Force reload feed
		if (uiinput == keybindings.forcereload && !highlighted->category) {
			//Clean cache
			clean_cache(highlighted->element->file);
			reload_feed(highlighted);
		}
	
		// Reload feed 
		if (uiinput == keybindings.reload && !highlighted->category) 
			reload_feed(highlighted);
		
		// Reload all feed 
		if (uiinput == keybindings.reloadall){ 
			for(feed_ptr = first_ptr; feed_ptr!=NULL; feed_ptr = feed_ptr->next)
				reload_feed(feed_ptr);
		}

		// Delete feed
		if (uiinput == keybindings.deletefeed) {
			
			if(highlighted == first_screen_feed){
				if(highlighted->next != NULL)
					first_screen_feed = highlighted->next;
				else if(highlighted->prev != NULL)
					first_screen_feed = highlighted->prev;
				else
					first_screen_feed = NULL;
			}

			if(highlighted->category)
				highlighted = ui_delete_feed(highlighted, highlighted->category_name);
			else if (highlighted->feed_name!=NULL)
				highlighted = ui_delete_feed(highlighted, highlighted->feed_name);
			else
				highlighted = ui_delete_feed(highlighted, highlighted->element->title);


		}

		// Up
		if (uiinput == KEY_UP) {
			if (highlighted->prev != NULL) {
				highlighted = highlighted->prev;
				pos_num--;
				if (highlightnum-1 < 1) 
					first_screen_feed = highlighted;
			}
		}
	
		// Down	
		if (uiinput == KEY_DOWN) {
			if (highlighted->next != NULL) {
				highlighted = highlighted->next;
				pos_num++;
				if (highlightnum+1 > LINES-4) 
					first_screen_feed = first_screen_feed->next;
			}
		}

		// Page down
		if (uiinput == KEY_NPAGE) {
			for (i = highlightnum; i <= LINES-5; i++) {
				if (highlighted->next != NULL) {
					highlighted = highlighted->next;
					pos_num++;
				} else {
					break;
				}
			}
			first_screen_feed = highlighted;
		}
	
		// Page up
		if (uiinput == KEY_PPAGE) {
			for (i = highlightnum; i <= LINES-5; i++) {
				if (highlighted->prev != NULL) {
					highlighted = highlighted->prev;
					pos_num--;
				} else {
					break;
				}
			}

			first_screen_feed = highlighted;
		}
		
		// Home
		if (uiinput == KEY_HOME){
			highlighted = first_ptr;
			first_screen_feed = first_ptr;
			pos_num=1;
		}
	
		// End
		if (uiinput == KEY_END){
			while (highlighted->next != NULL) {
				highlighted = highlighted->next;
				highlightnum++;
				pos_num++;
				if (highlightnum+1 > LINES-3) 
					// Fall off screen
					first_screen_feed = first_screen_feed->next;
			}
		}	

	
		// Move up
		if (uiinput == keybindings.moveup) {
			if (highlighted->prev != NULL) {
				swap_pointers (highlighted, highlighted->prev);
				highlighted = highlighted->prev;
					if (highlightnum-1 < 1) 
						first_screen_feed = highlighted;
			}
		}

		// Move down
		if (uiinput == keybindings.movedown) {
			if (highlighted->next != NULL) {
				swap_pointers (highlighted, highlighted->next);
				highlighted = highlighted->next;
				if (highlightnum+1 > LINES-4) 
					first_screen_feed = first_screen_feed->next;
			}
		}
	
		// Enter
		if (uiinput == '\n' && !highlighted->category ) {
			display_feed (highlighted); 
			move(0,0);
			clrtobot();
		}
	
		// Mark read
		if ( uiinput == keybindings.markread && !highlighted->category )
			highlighted->read=set_read(highlighted->element->item);
	
		// Mark unread
		if ( (uiinput == keybindings.markunread) && (!highlighted->category) )
			highlighted->read=set_unread(highlighted->element->item);
	
		// Rename feed
		if (uiinput == keybindings.changefeedname)
			ui_rename_feed(highlighted);


		// Redraw screen on ^L 
		if (uiinput == 12)
			clear();
	}
}
